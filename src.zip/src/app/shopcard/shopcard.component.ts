import { Component } from '@angular/core';

@Component({
  selector: 'app-shopcard',
  standalone: true,
  imports: [],
  templateUrl: './shopcard.component.html',
  styleUrl: './shopcard.component.css'
})
export class ShopcardComponent {

}
